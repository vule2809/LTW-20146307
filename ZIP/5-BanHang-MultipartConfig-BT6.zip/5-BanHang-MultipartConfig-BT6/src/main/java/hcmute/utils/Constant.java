package hcmute.utils;

public class Constant {
	public static final String DIR = "D:\\uploads";
}