package vn.star.Models;

import java.io.Serializable;

public class BookModel implements Serializable{
	private static final long serialVersionUID = 1L;

}
