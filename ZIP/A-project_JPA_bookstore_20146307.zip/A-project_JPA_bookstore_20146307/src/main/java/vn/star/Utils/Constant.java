package vn.star.Utils;

public class Constant {
	public static final String DIR = "D:\\uploads";
}