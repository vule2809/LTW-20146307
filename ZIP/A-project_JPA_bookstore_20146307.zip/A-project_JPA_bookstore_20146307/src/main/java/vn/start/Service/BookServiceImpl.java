package vn.start.Service;

import java.util.List;

import vn.star.Entity.Books;

public class BookServiceImpl implements IBookService{

	@Override
	public void insert(Books book) {
		
	}

	@Override
	public void update(Books book) {
		
	}

	@Override
	public void delete(int bookId) throws Exception {
		
	}

	@Override
	public Books findById(int bookId) {
		return null;
	}

	@Override
	public List<Books> findAll() {
		return null;
	}

	@Override
	public List<Books> findAll(int page, int pagesize) {
		return null;
	}

	@Override
	public int count() {
		return 0;
	}

}
