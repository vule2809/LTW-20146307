package vn.iotstar.Util;

public class Constant {
	public static final String DIR = "E:\\uploads";
}
