package vn.ute.util;

public class Constant {
	public static final String DIR = "E:\\uploads";
}
