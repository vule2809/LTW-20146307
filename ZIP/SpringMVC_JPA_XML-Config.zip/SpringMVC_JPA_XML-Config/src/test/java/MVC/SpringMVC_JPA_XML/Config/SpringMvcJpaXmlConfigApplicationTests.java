package MVC.SpringMVC_JPA_XML.Config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcJpaXmlConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
