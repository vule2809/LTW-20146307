package vn.shop.BLL;

import java.util.List;

import vn.shop.Models.provider;

public interface IproviderBLL {

	List<provider> findALL(); 
}
