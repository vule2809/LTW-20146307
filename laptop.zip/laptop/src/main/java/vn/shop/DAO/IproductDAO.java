package vn.shop.DAO;

public interface IproductDAO {

}
