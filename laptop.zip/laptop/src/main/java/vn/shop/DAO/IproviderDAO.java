package vn.shop.DAO;

import java.util.List;

import vn.shop.Models.provider;

public interface IproviderDAO {

	List<provider> findALL(); 
}
