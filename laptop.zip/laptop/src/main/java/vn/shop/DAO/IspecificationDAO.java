package vn.shop.DAO;

public interface IspecificationDAO {

}
