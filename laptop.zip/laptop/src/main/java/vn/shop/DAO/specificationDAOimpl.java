package vn.shop.DAO;

public class specificationDAOimpl implements IspecificationDAO {

}
